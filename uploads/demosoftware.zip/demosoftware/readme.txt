Demo Software Installer

Instructions:
1. Open this folder
2. Run the application (not included)
3. Enjoy

This is only a test file.
